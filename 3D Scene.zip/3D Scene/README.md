! READ THIS !

Since Visual Studio is no longer supported on macOS and I currently do not have access to Windows PS, hope it will be fine if I edit it using my Nvim editor and run it on macOS

Note that also had to modify some shaders info since current version of macOS use the 410 GLSL shader version, not the 440

I have compiled it for unix binaries capable systems and took a screenshot, please take a look. I have tried to compile it for Windows in the .exe format, but unfortunately can not test it.
